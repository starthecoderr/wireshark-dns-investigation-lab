# wireshark-dns-investigation-lab
SOC-style Wireshark DNS investigation lab using a Malware-Traffic-Analysis PCAP; includes filters, screenshots, and incident report.
